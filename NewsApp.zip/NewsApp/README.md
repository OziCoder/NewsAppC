1. Used Dagger Hilt for dependency injection.
2. SwipeRefresh enabled for reloading news after filtering.
3. This code follows the principles of MVVM design pattern.
4. Coroutines for network calls using Retrofit library.