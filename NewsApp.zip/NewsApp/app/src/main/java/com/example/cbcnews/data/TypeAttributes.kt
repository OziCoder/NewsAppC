package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class TypeAttributes(
    @SerializedName("url") var url: String? = null,
    @SerializedName("urlSlug") var urlSlug: String? = null,
    @SerializedName("deck") var deck: String? = null,
    @SerializedName("imageSmall") var imageSmall: String? = null,
    @SerializedName("imageLarge") var imageLarge: String? = null,
    @SerializedName("imageAspects") var imageAspects: String? = null,
    @SerializedName("flag") var flag: String? = null,
    @SerializedName("flags") var flags: Flags? = Flags(),
    @SerializedName("displayComments") var displayComments: Boolean? = null,
    @SerializedName("commentsSectionId") var commentsSectionId: String? = null,
    @SerializedName("trending") var trending: Trending? = Trending(),
    @SerializedName("mediaDuration") var mediaDuration: String? = null,
    @SerializedName("media") var media: String? = null,
    @SerializedName("mediaId") var mediaId: String? = null,
    @SerializedName("mediaStreamType") var mediaStreamType: String? = null,
    @SerializedName("mediaCaptionUrl") var mediaCaptionUrl: String? = null,
    @SerializedName("show") var show: String? = null,
    @SerializedName("showSlug") var showSlug: String? = null,
    @SerializedName("body") var body: Body? = Body(),
    @SerializedName("sectionList") var sectionList: ArrayList<String> = arrayListOf(),
    @SerializedName("sectionLabels") var sectionLabels: ArrayList<String> = arrayListOf(),
    @SerializedName("categories") var categories: ArrayList<Categories> = arrayListOf(),
    @SerializedName("contextualHeadlines") var contextualHeadlines: ArrayList<ContextualHeadlines> = arrayListOf(),
    @SerializedName("headline") var headline: Headline? = Headline(),
    @SerializedName("author") var author: Author? = Author()
)
