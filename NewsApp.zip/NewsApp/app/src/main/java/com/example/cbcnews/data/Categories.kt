package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Categories(
    @SerializedName("id") var id: Int? = null,
    @SerializedName("name") var name: String? = null,
    @SerializedName("path") var path: String? = null,
    @SerializedName("type") var type: String? = null,
    @SerializedName("slug") var slug: String? = null,
    @SerializedName("priority") var priority: Int? = null,
    @SerializedName("priorityWhenInlined") var priorityWhenInlined: Int? = null,
    @SerializedName("metadata") var metadata: MetaData? = null,
    @SerializedName("image") var image: String? = null,
    @SerializedName("bannerImage") var bannerImage: String? = null
)
