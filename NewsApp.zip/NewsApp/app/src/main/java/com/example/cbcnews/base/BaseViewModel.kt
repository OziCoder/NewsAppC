package com.example.cbcnews.base

import androidx.databinding.ObservableBoolean
import androidx.lifecycle.ViewModel
import com.example.cbcnews.manager.DataManagerRule
import java.lang.ref.WeakReference

abstract class BaseViewModel<N>(obj: DataManagerRule) : ViewModel() {
    private var mNavigator: WeakReference<N>? = null
    private val mIsLoading = ObservableBoolean()
    private var mDataManagerRule: DataManagerRule = obj


    open fun getNavigator(): N? {
        return mNavigator!!.get()
    }

    open fun setNavigator(navigator: N) {
        mNavigator = WeakReference(navigator)
    }

    open fun getIsLoading(): ObservableBoolean? {
        return mIsLoading
    }

    open fun setIsLoading(isLoading: Boolean) {
        mIsLoading.set(isLoading)
    }
}