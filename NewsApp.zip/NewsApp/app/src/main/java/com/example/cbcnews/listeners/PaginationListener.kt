package com.example.cbcnews.listeners

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cbcnews.ui.NewsRVAdapter

abstract class PaginationListener (layoutManager: LinearLayoutManager):
    RecyclerView.OnScrollListener() {
    val PAGE_START = 1
    val layoutManager: LinearLayoutManager = layoutManager
    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
        super.onScrolled(recyclerView, dx, dy)

        val visibleItemCount: Int = layoutManager.childCount
        val totalItemCount: Int = layoutManager.itemCount
        val firstVisibleItemPosition: Int = layoutManager.findFirstVisibleItemPosition()
        val isFiltered = (recyclerView.adapter as NewsRVAdapter).isFiltered
        if (!isLoading() && !isLastPage() && !isFiltered) {
            if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount && firstVisibleItemPosition >= 0) {
                loadMoreItems()
            }
        }
        /*if(isFiltered){
            (recyclerView.adapter as NewsRVAdapter).isFiltered = false
        }*/
    }

    protected abstract fun loadMoreItems()
    abstract fun getTotalPageCount(): Int
    abstract fun isLastPage(): Boolean
    abstract fun isLoading(): Boolean
}