package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Tracking(
    @SerializedName("subsection1") var subsection1: String? = null,
    @SerializedName("subsection2") var subsection2: String? = null,
    @SerializedName("subsection3") var subsection3: String? = null,
    @SerializedName("subsection4") var subsection4: String? = null,
    @SerializedName("contentarea") var contentarea: String? = null,
    @SerializedName("contenttype") var contenttype: String? = null
)
