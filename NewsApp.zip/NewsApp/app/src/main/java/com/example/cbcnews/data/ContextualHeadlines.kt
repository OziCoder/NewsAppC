package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class ContextualHeadlines(@SerializedName("contextId") var contextId: String? = null,
                               @SerializedName("headline") var headline: String? = null,
                               @SerializedName("contextualLineupSlug") var contextualLineupSlug: String? = null,
                               @SerializedName("pubQueueId") var pubQueueId: String? = null,
                               @SerializedName("headlineType") var headlineType: String? = null)
