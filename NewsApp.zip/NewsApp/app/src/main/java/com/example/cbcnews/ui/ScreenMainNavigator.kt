package com.example.cbcnews.ui

interface ScreenMainNavigator {
    fun displayFailureMessage(message: String)
}