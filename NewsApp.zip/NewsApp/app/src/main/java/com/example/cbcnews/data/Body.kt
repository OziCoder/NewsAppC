package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Body(
    @SerializedName("containsAudio") var containsAudio: Boolean? = null,
    @SerializedName("containsVideo") var containsVideo: Boolean? = null,
    @SerializedName("containsPhotogallery") var containsPhotogallery: Boolean? = null
)
