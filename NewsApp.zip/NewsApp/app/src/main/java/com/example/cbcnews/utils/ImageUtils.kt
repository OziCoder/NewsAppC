package com.example.cbcnews.utils

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.example.cbcnews.R

class ImageUtils {
    companion object{
        @BindingAdapter("imageUrl")
        fun setImageUrl(imageView: ImageView, url: String?) {
            val context = imageView.context
            if (url != null)
                Glide.with(context).load(url).placeholder(R.color.Gray).into(imageView)
        }
    }
}