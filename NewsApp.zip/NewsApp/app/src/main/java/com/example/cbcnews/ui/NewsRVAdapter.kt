package com.example.cbcnews.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.example.cbcnews.base.BaseViewHolder
import com.example.cbcnews.data.NewsResponseJson
import com.example.cbcnews.databinding.ItemListLoadingBinding
import com.example.cbcnews.databinding.ItemListNewsBinding
import com.example.cbcnews.utils.ImageUtils


class NewsRVAdapter : RecyclerView.Adapter<BaseViewHolder>(), Filterable {
    private val VIEW_TYPE_LOADING = 0
    private val VIEW_TYPE_NORMAL = 1
    private var isLoaderVisible = false
    var isFiltered = false
    private var listNews: ArrayList<NewsResponseJson> = ArrayList()
    private var listNewsF: ArrayList<NewsResponseJson> = ArrayList()
    fun setMainList(list: ArrayList<NewsResponseJson>) {
        if (this.listNewsF.size > 0) {
            this.listNewsF.clear()
        }
        this.listNewsF = ArrayList()
        this.listNewsF = list;
    }

    fun setIsFiltered(filtered: Boolean){
        isFiltered = filtered
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        return when (viewType) {
            VIEW_TYPE_NORMAL -> ViewHolder(
                ItemListNewsBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
            else -> {
                ProgressHolder(
                    ItemListLoadingBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                )
            }
        }
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        holder.onBind(position, listNews[position])
    }

    override fun getItemViewType(position: Int): Int {
        return if (isLoaderVisible) {
            if (position == listNews.size - 1) VIEW_TYPE_LOADING else VIEW_TYPE_NORMAL
        } else {
            VIEW_TYPE_NORMAL
        }
    }

    override fun getItemCount(): Int {
        return listNews.size
    }

    fun addItems(postItems: ArrayList<NewsResponseJson>) {
        listNews.addAll(postItems as ArrayList<NewsResponseJson>)
        notifyDataSetChanged()
    }

    fun addLoading() {
        isLoaderVisible = true
        listNews.add(NewsResponseJson())
        notifyItemInserted(listNews.size - 1)
    }

    fun removeLoading() {
        isLoaderVisible = false
        val position: Int = listNews.size - 1
        val item: NewsResponseJson? = getItem(position)
        if (item != null) {
            listNews.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    fun clear() {
        listNews.clear()
        notifyDataSetChanged()
    }

    private fun getItem(position: Int): NewsResponseJson? {
        return listNews[position]
    }

    class ViewHolder(internal var mBinding: ItemListNewsBinding) : BaseViewHolder(mBinding.root) {
        override fun onBind(position: Int, newsResponseJson: NewsResponseJson?) {
            mBinding.news = newsResponseJson
            ImageUtils.setImageUrl(mBinding.imgNews, mBinding.news?.typeAttributes?.imageLarge)
        }

        override fun clear() {
            mBinding.news = NewsResponseJson()
        }

    }

    class ProgressHolder(internal var progressBinding: ItemListLoadingBinding) :
        BaseViewHolder(progressBinding.root) {
        override fun onBind(position: Int, newsResponseJson: NewsResponseJson?) {
            progressBinding.progressBar.visibility = View.VISIBLE
        }

        override fun clear() {
            progressBinding.progressBar.visibility = View.GONE
        }


    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(p0: CharSequence?): FilterResults {
                val mFilteredResults = FilterResults()
                var mDataListBK = ArrayList<NewsResponseJson>()
                val charString = p0.toString()
                val filteredList = ArrayList<NewsResponseJson>()
                mDataListBK = if (charString.isNotEmpty()) {
                    for (product in listNewsF) {
                        if (charString.equals(product.type, true)) {
                            filteredList.add(product)
                        }
                    }
                    filteredList
                } else {
                    filteredList
                }
                mFilteredResults.values = mDataListBK
                mFilteredResults.count = mDataListBK.size
                return mFilteredResults
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun publishResults(p0: CharSequence?, p1: FilterResults?) {
                if (p1 != null) {
                    listNews = p1.values as ArrayList<NewsResponseJson>
                    setIsFiltered(true)
                }
                notifyDataSetChanged()
            }
        }
    }
}