package com.example.cbcnews.remote

import com.example.cbcnews.data.NewsResponseJson
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

interface RetrofitInterface {
    @GET("items?")
    fun getNews(@Query("lineupSlug") slug:String): Call<List<NewsResponseJson>?>?
}