package com.example.cbcnews.di.activity

import androidx.lifecycle.ViewModelProvider
import com.example.cbcnews.di.providers.ViewModelProviderFactory
import com.example.cbcnews.manager.DataManagerRule
import com.example.cbcnews.ui.ScreenMainVM
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class MainActivityModule {
    @Provides
    internal fun provideMainActivityViewModel(dataManagerRule: DataManagerRule): ScreenMainVM {
        return ScreenMainVM(dataManagerRule)
    }

    @Provides
    internal fun mainActivityModelProvider(screenMainVM: ScreenMainVM): ViewModelProvider.Factory {
        return ViewModelProviderFactory(screenMainVM)
    }
}