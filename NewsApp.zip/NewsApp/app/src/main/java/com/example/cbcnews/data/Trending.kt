package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Trending(
    @SerializedName("numViewers") var numViewers: Int? = null,
    @SerializedName("numViewersSRS") var numViewersSRS: Int? = null
)
