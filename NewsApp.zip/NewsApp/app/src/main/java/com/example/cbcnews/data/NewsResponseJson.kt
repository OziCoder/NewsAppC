package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class NewsResponseJson(
    @SerializedName("id") var id: Int? = null,
    @SerializedName("title") var title: String? = null,
    @SerializedName("description") var description: String? = null,
    @SerializedName("source") var source: String? = null,
    @SerializedName("sourceId") var sourceId: String? = null,
    @SerializedName("version") var version: String? = null,
    @SerializedName("publishedAt") var publishedAt: Long? = null,
    @SerializedName("readablePublishedAt") var readablePublishedAt: String? = null,
    @SerializedName("updatedAt") var updatedAt: Long? = null,
    @SerializedName("readableUpdatedAt") var readableUpdatedAt: String? = null,
    @SerializedName("type") var type: String = "",
    @SerializedName("active") var active: Boolean? = null,
    @SerializedName("draft") var draft: Boolean? = null,
    @SerializedName("embedTypes") var embedTypes: String? = null,
    @SerializedName("typeAttributes") var typeAttributes: TypeAttributes? = TypeAttributes(),
    @SerializedName("images") var images: Images = Images(),
    @SerializedName("language") var language: String? = null
) {
}