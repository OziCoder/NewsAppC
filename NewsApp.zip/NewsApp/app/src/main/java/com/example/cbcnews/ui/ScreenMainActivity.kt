package com.example.cbcnews.ui

import android.graphics.Color
import android.os.*
import android.view.View
import android.view.View.OnClickListener
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.cbcnews.BR
import com.example.cbcnews.R
import com.example.cbcnews.base.BaseActivity
import com.example.cbcnews.databinding.DialogFilterBinding
import com.example.cbcnews.databinding.LayoutMainActivityBinding
import com.example.cbcnews.listeners.PaginationListener
import com.example.cbcnews.utils.AppConstants
import com.example.cbcnews.utils.DialogUtils
import com.example.cbcnews.utils.ImageUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import dagger.hilt.android.AndroidEntryPoint
import java.lang.ref.WeakReference
import javax.inject.Inject


@AndroidEntryPoint
class ScreenMainActivity : BaseActivity<LayoutMainActivityBinding, ScreenMainVM>(), LifecycleOwner,
    ScreenMainNavigator,
    SwipeRefreshLayout.OnRefreshListener, OnClickListener {
    @Inject
    lateinit var mViewModel: ScreenMainVM

    private var mNewsRecyclerAdapter = NewsRVAdapter()
    private var currentPage: Int = 1
    private var isLastPage = false
    private val totalPage = 10
    private var isLoading = false
    var itemCount = 0
    private var mWeakRefBottomSheetDialog: WeakReference<BottomSheetDialog>? = null
    var mFilterBottomSheetDialog: BottomSheetDialog? = null

    lateinit var layoutMainActivityBinding: LayoutMainActivityBinding

    override fun getBindingVariable(): Int {
        return BR._all
    }

    override fun getLayoutId(): Int {
        return R.layout.layout_main_activity
    }

    override fun getViewModel(): ScreenMainVM {
        mViewModel = ViewModelProvider(this)[ScreenMainVM::class.java]
        return mViewModel
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layoutMainActivityBinding = getViewDataBinding()
        setContentView(layoutMainActivityBinding.root)
        mViewModel.setNavigator(this)
        layoutMainActivityBinding.lifecycleOwner = this
        setStatusBar()
        ImageUtils.setImageUrl(
            layoutMainActivityBinding.imgBanner,
            AppConstants.CBC_BANNER
        )
        setRequiredListeners()
        setUpRecyclerView()
    }

    private fun setStatusBar() {
        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor =
                ContextCompat.getColor(applicationContext, R.color.chart_red)
        }
    }

    private fun setRequiredListeners() {
        layoutMainActivityBinding.swipeRefresh.setOnRefreshListener(this)
        layoutMainActivityBinding.fabFilter.setOnClickListener(this)
    }

    private fun setUpRecyclerView() {
        layoutMainActivityBinding.newsRecycler.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(this)
        layoutMainActivityBinding.newsRecycler.layoutManager = layoutManager
        mNewsRecyclerAdapter = NewsRVAdapter()
        layoutMainActivityBinding.newsRecycler.adapter = mNewsRecyclerAdapter
        setUpScroller(layoutManager)
    }

    private fun setUpScroller(layoutManager: LinearLayoutManager) {
        if (isNetworkConnected()) {
            setupNews()
            layoutMainActivityBinding.newsRecycler.addOnScrollListener(object :
                PaginationListener(layoutManager) {
                override fun loadMoreItems() {
                    isLoading = true;
                    currentPage++;
                    setupNews()
                }

                override fun getTotalPageCount(): Int {
                    return totalPage
                }

                override fun isLastPage(): Boolean {
                    return isLastPage
                }

                override fun isLoading(): Boolean {
                    return isLoading
                }

            })
        } else {
            displayErrorMessage(getString(R.string.no_internet))
        }
    }

    private fun setupNews() {
        Handler(Looper.myLooper()!!).postDelayed({
            mViewModel.getLatestNews()
            if (currentPage != 1) mNewsRecyclerAdapter.removeLoading();
            mNewsRecyclerAdapter.addItems(mViewModel.newsList);
            mNewsRecyclerAdapter.setMainList(mViewModel.newsList)
            layoutMainActivityBinding.swipeRefresh.isRefreshing = false;
            if (currentPage < totalPage) {
                mNewsRecyclerAdapter.addLoading();
            } else {
                isLastPage = true;
            }
            isLoading = false;
        }, 1500)
    }

    override fun onRefresh() {
        if(isNetworkConnected()) {
            mNewsRecyclerAdapter.setIsFiltered(false)
            itemCount = 0;
            currentPage = 1;
            isLastPage = false;
            mNewsRecyclerAdapter.clear();
            setupNews()
        }else{
            layoutMainActivityBinding.swipeRefresh.isRefreshing = false
            mNewsRecyclerAdapter.setIsFiltered(false)
            mNewsRecyclerAdapter.clear();
            displayErrorMessage(getString(R.string.no_internet))
        }
    }

    private fun displayErrorMessage(message: String) {
        dismissDialog()
        val mBottomSheetDialog: BottomSheetDialog? =
            DialogUtils.displayFailureDialog(message, this, layoutInflater)
        if (mBottomSheetDialog != null) {
            mWeakRefBottomSheetDialog = WeakReference(mBottomSheetDialog)
        }
    }

    private fun dismissDialog() {
        if (mWeakRefBottomSheetDialog != null) {
            val mBottomSheetDialog: BottomSheetDialog? = mWeakRefBottomSheetDialog!!.get()
            if (mWeakRefBottomSheetDialog != null && mBottomSheetDialog != null && mBottomSheetDialog.isShowing) {
                mBottomSheetDialog.dismiss()
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.fabFilter -> {
                showDropDownFilter()
            }
        }
    }

    private fun showDropDownFilter() {
        mFilterBottomSheetDialog =
            BottomSheetDialog(layoutMainActivityBinding.root.context, R.style.TransparentDialog)
        val dBinding: DialogFilterBinding =
            DialogFilterBinding.inflate(mFilterBottomSheetDialog!!.layoutInflater, null, false)
        mFilterBottomSheetDialog?.setContentView(dBinding.root)
        val params = (dBinding.root.parent as View)
            .layoutParams as CoordinatorLayout.LayoutParams
        val behavior = params.behavior
        (dBinding.root.parent as View).setBackgroundColor(Color.TRANSPARENT)
        mFilterBottomSheetDialog!!.show()
        mFilterBottomSheetDialog!!.setCanceledOnTouchOutside(true)
        val arrOptionsList = ArrayList<String>()
        arrOptionsList.clear()
        arrOptionsList.addAll(mViewModel.getTypeList())
        val customArrayAdapter = ArrayAdapter<String>(
            dBinding.root.context,
            R.layout.simple_textview_dropdown,
            arrOptionsList
        )
        dBinding.listView.adapter = customArrayAdapter
        dBinding.listView.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                mFilterBottomSheetDialog!!.dismiss()
                applyFilter(arrOptionsList[position])
            }
    }

    private fun applyFilter(filter: String) {
        mNewsRecyclerAdapter.removeLoading()
        mNewsRecyclerAdapter.filter.filter(filter)
    }

    override fun displayFailureMessage(message: String) {
        displayErrorMessage(message)
    }

}