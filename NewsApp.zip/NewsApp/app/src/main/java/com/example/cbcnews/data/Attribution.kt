package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Attribution(
    @SerializedName("level1") var level1: String? = null,
    @SerializedName("level2") var level2: String? = null,
    @SerializedName("level3") var level3: String? = null
)
