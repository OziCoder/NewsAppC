package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Author(
    @SerializedName("name") var name: String? = null,
    @SerializedName("display") var display: String? = null,
    @SerializedName("image") var image: String? = null
) {
}