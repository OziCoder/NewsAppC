package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Headline(
    @SerializedName("type") var type: String? = null,
    @SerializedName("mediaId") var mediaId: String? = null
)
