package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class MetaData(
    @SerializedName("tracking") var tracking: Tracking? = Tracking(),
    @SerializedName("attribution") var attribution: Attribution? = Attribution(),
    @SerializedName("adHierarchy") var adHierarchy: String? = null,
    @SerializedName("polopolyDeptName") var polopolyDeptName: String? = null,
    @SerializedName("polopolyExternalId") var polopolyExternalId: String? = null,
    @SerializedName("orderLineupId") var orderLineupId: String? = null,
    @SerializedName("orderLineupSlug") var orderLineupSlug: String? = null,
    @SerializedName("mpxCategoryName") var mpxCategoryName: String? = null,
    @SerializedName("pageTitle") var pageTitle: String? = null,
    @SerializedName("pageDescription") var pageDescription: String? = null
)
