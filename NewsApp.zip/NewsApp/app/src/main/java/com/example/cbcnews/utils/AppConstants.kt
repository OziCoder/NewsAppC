package com.example.cbcnews.utils

object AppConstants {
    const val API_CODE_PERMISSION_REQUEST = 0
    const val BASE_URL = "https://www.cbc.ca/aggregate_api/v1/"
    const val CBC_BANNER = "https://i.cbc.ca/1.5486608.1583513203!/fileImage/httpImage/image.jpg_gen/derivatives/original_1180/cbc-news.jpg"
}