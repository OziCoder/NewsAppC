package com.example.cbcnews.ui

import androidx.lifecycle.viewModelScope
import com.example.cbcnews.base.BaseViewModel
import com.example.cbcnews.data.NewsResponseJson
import com.example.cbcnews.manager.DataManagerRule
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class ScreenMainVM @Inject constructor(
    private val dataManager: DataManagerRule
) : BaseViewModel<ScreenMainNavigator>(dataManager) {
    var jobDownload: Job? = null
    var newsList: ArrayList<NewsResponseJson> = ArrayList()
    fun getLatestNews(){
        jobDownload = viewModelScope.launch(Dispatchers.IO) {
            val call = dataManager.networkCall.getNews("news")
            call?.enqueue(object : Callback<List<NewsResponseJson>?>{
                override fun onResponse(
                    call: Call<List<NewsResponseJson>?>,
                    response: Response<List<NewsResponseJson>?>
                ) {
                    val news = response.body()
                    newsList.addAll(news as ArrayList<NewsResponseJson>)
                }

                override fun onFailure(call: Call<List<NewsResponseJson>?>, t: Throwable) {
                    val error = t.message
                    this@ScreenMainVM.getNavigator()?.displayFailureMessage(error.toString())
                }
            })
        }
    }

    fun getTypeList(): ArrayList<String>{
        var arr: ArrayList<String> = arrayListOf()
        newsList.distinctBy {
            it.type
        }.forEach {
            arr.add(it.type)
        }
        return arr
    }
}