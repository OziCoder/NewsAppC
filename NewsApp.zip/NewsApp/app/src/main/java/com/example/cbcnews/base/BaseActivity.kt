package com.example.cbcnews.base

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import com.example.cbcnews.R
import com.example.cbcnews.databinding.DialogMsgPermissionBinding
import com.example.cbcnews.utils.AppConstants
import com.example.cbcnews.utils.AppUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import java.util.ArrayList

abstract class BaseActivity<T : ViewDataBinding, V: BaseViewModel<*>> : AppCompatActivity(), BaseFragment.Callback {
    private lateinit var mViewDataBinding: T
    private var mViewModel: V? = null
    var mProgressDialog: Dialog? = null
    fun getViewDataBinding(): T = mViewDataBinding
    abstract fun getBindingVariable(): Int
    abstract fun getLayoutId(): Int
    abstract fun getViewModel(): V
    override fun onFragmentAttached() {}
    override fun onFragmentDetached(tag: String) {}
    var isPerManuallyDialogOpened = false
    private val permissions = arrayOf(
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.INTERNET
    )

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!arePermissionsEnabled()) {
                if (isPerManuallyDialogOpened) {
                    return
                } else {
                    requestMultiplePermissions()
                    return
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        performDataBinding()
    }

    private fun performDataBinding() {
        mViewDataBinding = DataBindingUtil.setContentView(this, getLayoutId())
        this.mViewModel = if (mViewModel == null) getViewModel() else mViewModel
        mViewDataBinding.setVariable(getBindingVariable(), mViewModel)
        mViewDataBinding.executePendingBindings()
    }

    @RequiresApi(Build.VERSION_CODES.M)
    open fun arePermissionsEnabled(): Boolean {
        for (permission in permissions) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) return false
        }
        return true
    }

    open fun requestMultiplePermissions() {
        val remainingPermissions: MutableList<String> = ArrayList()
        for (permission in permissions) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    permission
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                remainingPermissions.add(permission)
            }
        }
        if (remainingPermissions.size > 0) {
            ActivityCompat.requestPermissions(
                this,
                remainingPermissions.toTypedArray(),
                AppConstants.API_CODE_PERMISSION_REQUEST
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AppConstants.API_CODE_PERMISSION_REQUEST) {
            for (i in grantResults.indices) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    val mBottomSheetDialog = BottomSheetDialog(this, R.style.TransparentDialog)
                    val mBinding: DialogMsgPermissionBinding =
                        DialogMsgPermissionBinding.inflate(layoutInflater, null, false)
                    mBottomSheetDialog.setContentView(mBinding.root)
                    mBottomSheetDialog.setCancelable(false)
                    (mBinding.root.parent as View).setBackgroundColor(
                        ContextCompat.getColor(
                            this,
                            android.R.color.transparent
                        )
                    )
                    mBinding.message =
                        resources.getString(R.string.allow_permissions)
                    mBinding.btnDialogOk.setOnClickListener { v ->
                        isPerManuallyDialogOpened = false
                        val intent = Intent()
                        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        val uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        startActivity(intent)
                    }
                    mBottomSheetDialog.show()
                    mBinding.executePendingBindings()
                    isPerManuallyDialogOpened = true
                    return
                }
            }
        }
    }

    fun hideLoading() {
        if (mProgressDialog != null && mProgressDialog?.isShowing!!) {
            mProgressDialog?.cancel()
        }
    }

    fun showLoading() {
        if (isNetworkConnected()) {
            hideLoading()
            mProgressDialog = AppUtils.showLoadingDialog(this)
        } else {
            redSnackBar()
        }
    }

    fun isNetworkConnected(): Boolean {
        return AppUtils.isNetworkConnected(applicationContext)
    }

    fun redSnackBar(message: String = getString(R.string.no_internet)) {
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG)
            .setTextColor(Color.WHITE).setBackgroundTint(Color.RED)
            .show()
    }
}