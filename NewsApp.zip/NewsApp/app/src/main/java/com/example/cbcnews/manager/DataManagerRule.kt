package com.example.cbcnews.manager

import com.example.cbcnews.remote.RetrofitInterface
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataManagerRule @Inject constructor(val networkCall: RetrofitInterface) {
}