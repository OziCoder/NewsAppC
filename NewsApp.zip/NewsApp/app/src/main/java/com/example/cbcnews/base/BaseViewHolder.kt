package com.example.cbcnews.base

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.cbcnews.data.NewsResponseJson

abstract class BaseViewHolder(itemView: View?) : RecyclerView.ViewHolder(itemView!!) {
    abstract fun onBind(position: Int, newsResponseJson: NewsResponseJson?)
    protected abstract fun clear()

}