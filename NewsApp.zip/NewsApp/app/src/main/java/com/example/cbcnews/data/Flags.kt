package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Flags(
    @SerializedName("status") var status: String? = null,
    @SerializedName("label") var label: String? = null
)
