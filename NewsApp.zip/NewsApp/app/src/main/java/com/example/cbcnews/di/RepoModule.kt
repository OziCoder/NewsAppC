package com.example.cbcnews.di

import com.example.cbcnews.manager.DataManagerRule
import com.example.cbcnews.remote.RetrofitInterface
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class RepoModule {
    @Provides
    @Singleton
    internal fun provideRepository(
        networkCall: RetrofitInterface,
    ): DataManagerRule {
        return DataManagerRule(
            networkCall,
        )
    }
}