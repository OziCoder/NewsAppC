package com.example.cbcnews.utils

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import com.example.cbcnews.R
import com.example.cbcnews.databinding.DialogMsgPermissionBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

class DialogUtils {
    companion object {
        fun displayFailureDialog(
            message: String?,
            mCtx: Context,
            layoutInflater: LayoutInflater
        ): BottomSheetDialog? {
            var mBottomSheetDialog: BottomSheetDialog? = null
            mBottomSheetDialog = BottomSheetDialog(mCtx, R.style.TransparentDialog)
            val mBinding: DialogMsgPermissionBinding =
                DialogMsgPermissionBinding.inflate(layoutInflater)
            mBottomSheetDialog.setContentView(mBinding.getRoot())
            val bottomSheet =
                mBottomSheetDialog.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
            val behavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet as View)
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
            (mBinding.root.parent as View).setBackgroundColor(
                ContextCompat.getColor(mCtx, R.color.transparent)
            )
            mBinding.btnDialogOk.visibility = View.GONE
            mBinding.message = message
            mBottomSheetDialog.show()
            return mBottomSheetDialog
        }

    }
}