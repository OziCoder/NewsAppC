package com.example.cbcnews.data

import com.google.gson.annotations.SerializedName

data class Images(@SerializedName("square_140") var square140: String = "")
